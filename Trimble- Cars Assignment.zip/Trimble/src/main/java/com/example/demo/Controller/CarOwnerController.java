package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Car;
import com.example.demo.Entity.User;
import com.example.demo.Service.CarService;
import com.example.demo.Service.UserService;

@RestController
@RequestMapping("/owner")
public class CarOwnerController {

    @Autowired
    private CarService carService;

    @Autowired
    private UserService userService;

    // Owner Registration
    @PostMapping("/register")
    public User registerOwner(@RequestBody User owner) {
   	 String username = owner.getUsername();
	 String password = owner.getPassword();
	 String role = owner.getRole();
	 owner.setUsername(username); 
	 owner.setPassword(password); 
	 owner.setRole(role); 
     return userService.registerUser(owner);
    }

    // Register Car
    @PostMapping("/registerCar/{ownerId}")
    public Car registerCar(@RequestBody Car car, @PathVariable Long ownerId) {
        return carService.registerCar(car, ownerId);
    }

    // Get all cars of the owner
    @GetMapping("/myCars/{ownerId}")
    public List<Car> getMyCars(@PathVariable Long ownerId) {
        return carService.getCarsByOwner(ownerId);
    }
}
