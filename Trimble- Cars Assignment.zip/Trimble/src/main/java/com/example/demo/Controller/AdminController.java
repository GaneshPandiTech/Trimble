package com.example.demo.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Car;
import com.example.demo.Entity.Lease;
import com.example.demo.Entity.User;
import com.example.demo.Service.CarService;
import com.example.demo.Service.LeaseService;
import com.example.demo.Service.UserService;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private CarService carService;

    @Autowired
    private LeaseService leaseService;

    // Admin registration 
    @PostMapping("/register")
    public User registerAdmin(@RequestBody User admin) {
   	 String username = admin.getUsername();
	 String password = admin.getPassword();
	 String role = admin.getRole();
	 admin.setUsername(username); 
	 admin.setPassword(password); 
	 admin.setRole(role); 
     return userService.registerUser(admin);
    }

    // Manage users
    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @DeleteMapping("/users/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }

    // Manage cars
    @GetMapping("/cars")
    public List<Car> getAllCars() {
        return carService.getAllCars();
    }

    @PostMapping("/registerCar/{ownerId}")
    public Car registerCar(@RequestBody Car car, @PathVariable Long ownerId) {
        return carService.registerCar(car, ownerId);
    }

    @DeleteMapping("/cars/{id}")
    public void deleteCar(@PathVariable Long id) {
        carService.deleteCar(id);
    }

    // Manage leases
    @GetMapping("/leases")
    public List<Lease> getAllLeases() {
        return leaseService.getAllLeases();
    }

    @PostMapping("/endLease/{leaseId}")
    public Lease endLease(@PathVariable Long leaseId) {
        return leaseService.endLease(leaseId);
    }
}
