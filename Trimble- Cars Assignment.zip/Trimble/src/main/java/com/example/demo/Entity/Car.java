package com.example.demo.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "car")  
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String model;
    private String plateNumber;
    private String status;

    @ManyToOne
    private User owner;

    public Car() {}  

    public Car(Long id, String model, String plateNumber, String status, User owner) {
        this.id = id;
        this.model = model;
        this.plateNumber = plateNumber;
        this.status = status;
        this.owner = owner;
    }

   
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }
    public String getPlateNumber() { return plateNumber; }
    public void setPlateNumber(String plateNumber) { this.plateNumber = plateNumber; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public User getOwner() { return owner; }
    public void setOwner(User owner) { this.owner = owner; }
}
