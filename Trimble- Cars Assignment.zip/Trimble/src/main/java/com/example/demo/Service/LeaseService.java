package com.example.demo.Service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Car;
import com.example.demo.Entity.Lease;
import com.example.demo.Entity.User;
import com.example.demo.Repository.CarRepository;
import com.example.demo.Repository.LeaseRepository;
import com.example.demo.Repository.UserRepository;

@Service
public class LeaseService {
    @Autowired
    private LeaseRepository leaseRepository;
    @Autowired
    private CarRepository carRepository;
    @Autowired
    private UserRepository userRepository;

    public Lease startLease(Long customerId, Long carId) {
        User customer = userRepository.findById(customerId).orElseThrow();
        long activeLeases = leaseRepository.findByCustomer(customer).stream()
            .filter(l -> l.getEndDate() == null)
            .count();

        if (activeLeases >= 2)
            throw new RuntimeException("Maximum 2 active leases allowed");

        Car car = carRepository.findById(carId).orElseThrow();
        if (!"IDEAL".equals(car.getStatus()))
            throw new RuntimeException("Car is not available");

        Lease lease = new Lease();
        lease.setCar(car);
        lease.setCustomer(customer);
        lease.setStartDate(LocalDate.now());

        car.setStatus("ON_LEASE");
        carRepository.save(car);
        return leaseRepository.save(lease);
    }

    public Lease endLease(Long leaseId) {
        Lease lease = leaseRepository.findById(leaseId).orElseThrow();
        if (lease.getEndDate() != null)
            throw new RuntimeException("Lease already ended");
        lease.setEndDate(LocalDate.now());

        Car car = lease.getCar();
        car.setStatus("IDEAL");
        carRepository.save(car);
        return leaseRepository.save(lease);
    }
    
    public List<Lease> getLeaseHistory(Long customerId) {
        User customer = userRepository.findById(customerId).orElseThrow();
        return leaseRepository.findByCustomer(customer);
    }
    
    public List<Lease> getAllLeases() {
        return leaseRepository.findAll();
    }
}
