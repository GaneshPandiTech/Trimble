package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Car;
import com.example.demo.Entity.User;
import com.example.demo.Repository.CarRepository;
import com.example.demo.Repository.UserRepository;

@Service
public class CarService {
    @Autowired
    private CarRepository carRepository;

    @Autowired
    private UserRepository userRepository;

    public Car registerCar(Car car, Long ownerId) {
        User owner = userRepository.findById(ownerId).orElseThrow();
        car.setOwner(owner);

        
        if (car.getStatus() == null) {
            car.setStatus("IDEAL"); 
        } else {
            String status = car.getStatus().toUpperCase();
            if (!status.equals("IDEAL") && !status.equals("ON_LEASE") && !status.equals("ON_SERVICE")) {
                throw new IllegalArgumentException("Invalid status. Allowed: IDEAL, ON_LEASE, ON_SERVICE");
            }
            car.setStatus(status); 
        }

        return carRepository.save(car);
    }

    public List<Car> getCarsByOwner(Long ownerId) {
        User owner = userRepository.findById(ownerId).orElseThrow();
        return carRepository.findByOwner(owner);
    }

    public List<Car> getAllCars() {
        return carRepository.findAll();
    }
    public void deleteCar(Long id) {
        carRepository.deleteById(id);
    }
}
