package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.Entity.Car;
import com.example.demo.Entity.Lease;
import com.example.demo.Entity.User;
import com.example.demo.Service.CarService;
import com.example.demo.Service.LeaseService;
import com.example.demo.Service.UserService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CarService carService;
    @Autowired
    private LeaseService leaseService;
    
    @Autowired
    private UserService userService; 
    // Customer Registration
    
    @PostMapping("/register")
    public User registerCustomer(@RequestBody User customer) {
    	 String username = customer.getUsername();
    	 String password = customer.getPassword();
    	 String role = customer.getRole();
    	 customer.setUsername(username); 
    	 customer.setPassword(password); 
    	 customer.setRole(role); 
         return userService.registerUser(customer);
    }

    @GetMapping("/cars")
    public List<Car> getAllCars() {
        return carService.getAllCars();
    }

    @PostMapping("/lease/{customerId}/{carId}")
    public Lease startLease(@PathVariable Long customerId, @PathVariable Long carId) {
        return leaseService.startLease(customerId, carId);
    }

    @PostMapping("/endLease/{leaseId}")
    public Lease endLease(@PathVariable Long leaseId) {
        return leaseService.endLease(leaseId);
    }
    
    @GetMapping("/leaseHistory/{customerId}")
    public List<Lease> getLeaseHistory(@PathVariable Long customerId) {
        return leaseService.getLeaseHistory(customerId);
    }
   
}
